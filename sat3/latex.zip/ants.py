def think():
    walk()
    if garbagging():
        if random() > relative_density():
            if cel_is_clear():
                put_dead_ant()
    else:
        if random() < relative_density():
            if not cel_is_clear():
                get_dead_ant()